import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:produitsapp/ProduitItem.dart';
import 'package:produitsapp/form/addProduitForm.dart';
import 'package:produitsapp/form/updateProduitForm.dart';
import 'package:produitsapp/list_produits_fav.dart';
import 'package:produitsapp/model/produit.dart';
import 'package:produitsapp/profile.dart';

class ListeProduits extends StatefulWidget {
  const ListeProduits({super.key});

  @override
  State<ListeProduits> createState() => _ListeProduitsState();
}

class _ListeProduitsState extends State<ListeProduits> {
  int _currentIndex = 0;
  String? userRole;
  final List<Widget> _pages = [
    Center(child: Text('acceuil', style: TextStyle(fontSize: 24))),
    ListProduitsFav(),
    Profile(),
  ];
  FirebaseFirestore db = FirebaseFirestore.instance;

  Future<String?> getUserRole() async {
    User? user = FirebaseAuth.instance.currentUser;

    if (user != null) {
      DocumentSnapshot doc = await FirebaseFirestore.instance
          .collection('utilisateur')
          .doc(user.uid)
          .get();
      return doc['role'] as String?;
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    getUserRole().then((role) {
      setState(() {
        userRole = role;
      });
    }).catchError((error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erreur : $error')),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Liste des produits"),
      ),
      body: _currentIndex == 0
          ? StreamBuilder(
              stream: db.collection('produits').snapshots(),
              builder: (BuildContext context,
                  AsyncSnapshot<QuerySnapshot> snapshot) {
                if (snapshot.hasError) {
                  return const Center(child: Text("une erreur est survenue"));
                }
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                List<Produit> produits = snapshot.data!.docs.map((doc) {
                  return Produit.fromFirestore(doc);
                }).toList();
                return ListView.builder(
                    itemCount: produits.length,
                    itemBuilder: (context, index) => Slidable(
                        key: ValueKey(index),
                        endActionPane:
                            ActionPane(motion: const DrawerMotion(), children: [
                          SlidableAction(
                            onPressed: (BuildContext context) {
                              db
                                  .collection('produits')
                                  .doc(produits[index].id)
                                  .update({"fav": !produits[index].fav});
                            },
                            backgroundColor:
                                const Color.fromARGB(255, 228, 223, 98),
                            foregroundColor: Colors.white,
                            icon: !produits[index].fav
                                ? Icons.star_border
                                : Icons.star,
                          ),
                          SlidableAction(
                            onPressed: userRole == 'admin'
                                ? (BuildContext context) {
                                    showDialog(
                                      context: context,
                                      builder: (BuildContext context) {
                                        return AlertDialog(
                                          content: ProduitFormUpdate(
                                            initialData: {
                                              'marque': produits[index].marque,
                                              'designation':
                                                  produits[index].designation,
                                              'categorie':
                                                  produits[index].categorie,
                                              'prix': produits[index].prix,
                                              'quantite':
                                                  produits[index].quantite,
                                              'image': produits[index].image,
                                              'fav': produits[index].fav,
                                            },
                                            onSubmit: (updatedProduit) {
                                              db
                                                  .collection('produits')
                                                  .doc(produits[index].id)
                                                  .update(updatedProduit)
                                                  .then((_) {
                                                Navigator.of(context).pop();
                                                ScaffoldMessenger.of(context)
                                                    .showSnackBar(
                                                  const SnackBar(
                                                    content: const Text(
                                                        'Produit mis à jour avec succès'),
                                                    backgroundColor:
                                                        Colors.green,
                                                  ),
                                                );
                                              }).catchError((error) {
                                                ScaffoldMessenger.of(context)
                                                    .showSnackBar(
                                                  SnackBar(
                                                      content: Text(
                                                          'Erreur : $error')),
                                                );
                                              });
                                            },
                                          ),
                                        );
                                      },
                                    );
                                  }
                                : null,
                            backgroundColor:
                                userRole == 'admin' ? Colors.blue : Colors.grey,
                            foregroundColor: Colors.white,
                            icon: Icons.edit,
                          ),
                          SlidableAction(
                            onPressed: userRole == 'admin'
                                ? (BuildContext context) {
                                    db
                                        .collection('produits')
                                        .doc(produits[index].id)
                                        .delete();
                                  }
                                : null,
                            backgroundColor:
                                userRole == 'admin' ? Colors.red : Colors.grey,
                            foregroundColor: Colors.white,
                            icon: Icons.delete,
                          )
                        ]),
                        child: ProduitItem(produit: produits[index])));
              })
          : _pages[_currentIndex],
      floatingActionButton: _currentIndex == 0 && userRole == 'admin'
          ? FloatingActionButton(
              onPressed: () {
                showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: Text('Ajouter un Produit'),
                        content: ProduitForm(
                          onSubmit: (produitData) {
                            db
                                .collection('produits')
                                .add(produitData)
                                .then((_) {
                              Navigator.of(context).pop();
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('Produit ajouté avec succès'),
                                  backgroundColor: Colors.green,
                                ),
                              );
                            }).catchError((error) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Erreur : $error')),
                              );
                            });
                          },
                        ),
                      );
                    });
              },
              tooltip: 'ajouter un produit',
              child: const Icon(Icons.add))
          : null,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Accueil',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: 'Favoris',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profil',
          ),
        ],
      ),
    );
  }
}
